

// Products have a name and price.
// ShoppingCarts have a list of Products.
// Products can be added to or removed from a ShoppingCart.
// A ShoppingCart must be able to provide a total price for its list of Products.

// TEST 1: Create a ShoppingCart, then add 2 "Apple" Products for $4.95 each and 1 "Orange" Product for $3.99, and check that the ShoppingCart total price is correct.
// TEST 2: Create a ShoppingCart and add 3 "Apple" products, then remove 1 "Apple" product, and check that total price is correct.

let products = {
  apple: 4.95,
  orange: 3.99
}

function shoppingCart() {
 // shoppingCard = [ ]
}

function addProducts() {

}

function removeProducts() {
 // totalPrice = totalPrice - product removed
}

function totalPrice() {
  // sum = 0
  // if (isEmpty? === false ) {
 // total = total + addProducts + "$"
 // } else {
 // return $0
 // }

 //totalCost = `${total}` + 


}
