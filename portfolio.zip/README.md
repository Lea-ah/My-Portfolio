# My-Portfolio

I started creating this portfolio in June 2022 using black/white/grey and very pop colours!
I wanted to create an effect of surprise with a portfolio that is very dark and lighten up on hover.
